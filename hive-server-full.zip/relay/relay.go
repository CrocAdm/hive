package main

import (
  "crypto/sha256"
  "encoding/hex"
  "fmt"
  "io"
  "log"
  "net"
  "net/http"
  "os"
  "path/filepath"
  "time"
  "github.com/gorilla/websocket"
)

func generateDomain() string {
  h := sha256.Sum256([]byte(time.Now().String()))
  return hex.EncodeToString(h[:])[:16] + ".hive"
}

func getPublicIP() string {
  conn, _ := net.Dial("udp", "8.8.8.8:80")
  defer conn.Close()
  return conn.LocalAddr().(*net.UDPAddr).IP.String()
}

func handleUpload(w http.ResponseWriter, r *http.Request) {
  r.ParseMultipartForm(100 << 20)
  files := r.MultipartForm.File["files"]
  domain := generateDomain()
  ip, port := getPublicIP(), "8080"
  dir := filepath.Join("sites", domain)
  os.MkdirAll(dir, 0755)

  for _, f := range files {
    in, _ := f.Open()
    defer in.Close()
    out, _ := os.Create(filepath.Join(dir, f.Filename))
    defer out.Close()
    io.Copy(out, in)
  }

  go func() {
    mux := http.NewServeMux()
    mux.Handle("/"+domain+"/", http.StripPrefix("/"+domain+"/", http.FileServer(http.Dir(dir))))
    http.ListenAndServe(":8080", mux)
  }()

  time.Sleep(1 * time.Second)
  conn, _, err := websocket.DefaultDialer.Dial("ws://127.0.0.1:443/join", nil)
  if err == nil {
    defer conn.Close()
    conn.WriteMessage(websocket.TextMessage, []byte(fmt.Sprintf("publish:%s:%s:%s", domain, ip, port)))
  }

  w.Write([]byte(domain))
}

func main() {
  os.MkdirAll("sites", 0755)
  http.HandleFunc("/upload", handleUpload)
  log.Println("🚀 HiveRelay on :8888")
  log.Fatal(http.ListenAndServe(":8888", nil))
}