package main

import (
    "log"
    "net/http"
    "strings"
    "github.com/gorilla/websocket"
)

func main() {
    log.Println("Hive proxy running at http://localhost:8899")
    http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
        domain := strings.Trim(r.URL.Path, "/")
        lobbyAddrs := []string{
            "ws://127.0.0.1:443/join",
            "ws://127.0.0.1:80/join",
        }

        var conn *websocket.Conn
        for _, addr := range lobbyAddrs {
            c, _, err := websocket.DefaultDialer.Dial(addr, nil)
            if err == nil {
                conn = c
                break
            } else {
                log.Printf("❌ Failed: %s - %v", addr, err)
            }
        }

        if conn == nil {
            http.Error(w, "Could not connect to any lobby address", 503)
            return
        }
        defer conn.Close()

        conn.WriteMessage(websocket.TextMessage, []byte("resolve:" + domain))
        _, msg, err := conn.ReadMessage()
        if err != nil {
            http.Error(w, "Failed to resolve domain", 500)
            return
        }

        parts := strings.Split(string(msg), ":")
        if len(parts) != 2 {
            http.Error(w, "Invalid response from lobby", 500)
            return
        }

        target := "http://" + parts[0] + ":" + parts[1] + "/" + domain + "/"
        log.Println("🔁 Proxying to", target)
        http.Redirect(w, r, target, http.StatusTemporaryRedirect)
    })

    http.ListenAndServe(":8899", nil)
}