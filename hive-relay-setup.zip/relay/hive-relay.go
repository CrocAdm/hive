// ===== Hive Relay Server =====
// File: hive-relay.go

package main

import (
    "fmt"
    "log"
    "net/http"

    "github.com/gorilla/websocket"
)

var upgrader = websocket.Upgrader{CheckOrigin: func(r *http.Request) bool { return true }}

var sites = make(map[string]string)

func handleJoin(w http.ResponseWriter, r *http.Request) {
    conn, err := upgrader.Upgrade(w, r, nil)
    if err != nil {
        return
    }
    defer conn.Close()

    for {
        _, msg, err := conn.ReadMessage()
        if err != nil {
            return
        }

        text := string(msg)
        if len(text) > 8 && text[:8] == "publish:" {
            parts := text[8:]
            split := make([]string, 2)
            for i, s := range parts {
                if s == ':' {
                    split[0] = parts[:i]
                    split[1] = parts[i+1:]
                    break
                }
            }
            if split[0] != "" && split[1] != "" {
                sites[split[0]] = split[1]
            }
        } else if len(text) > 8 && text[:8] == "resolve:" {
            domain := text[8:]
            target, ok := sites[domain]
            if ok {
                conn.WriteMessage(websocket.TextMessage, []byte(target))
            }
        }
    }
}

func main() {
    http.HandleFunc("/join", handleJoin)
    log.Println("HiveRelay on :443")
    log.Fatal(http.ListenAndServe(":443", nil))
}