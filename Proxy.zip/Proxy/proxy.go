// ===== Hive Proxy Server (SERVER SIDE) =====
// File: hive-proxy.go

package main

import (
    "fmt"
    "log"
    "net"
    "net/http"
    "strings"
    "github.com/gorilla/websocket"
)

var lobbyAddrs = []string{
    "ws://127.0.0.1:443/join",
    "ws://127.0.0.1:80/join",
    "ws://127.0.0.1:8888/join", // fallback relay
}

func resolve(domain string) (string, error) {
    for _, addr := range lobbyAddrs {
        conn, _, err := websocket.DefaultDialer.Dial(addr, nil)
        if err != nil {
            log.Printf("[!] Failed: %s -> %v", addr, err)
            continue
        }
        defer conn.Close()

        conn.WriteMessage(websocket.TextMessage, []byte("resolve:"+domain))
        _, msg, err := conn.ReadMessage()
        if err != nil {
            return "", err
        }

        parts := strings.Split(string(msg), ":")
        if len(parts) != 2 {
            return "", fmt.Errorf("invalid response: %s", msg)
        }

        return fmt.Sprintf("http://%s:%s/%s/", parts[0], parts[1], domain), nil
    }
    return "", fmt.Errorf("no available lobby")
}

func proxyHandler(w http.ResponseWriter, r *http.Request) {
    domain := strings.Trim(r.URL.Path, "/")
    if domain == "" {
        http.Error(w, "Invalid domain", 400)
        return
    }

    target, err := resolve(domain)
    if err != nil {
        log.Printf("[!] Resolve failed for %s: %v", domain, err)
        http.Error(w, "Could not resolve domain", 502)
        return
    }

    log.Printf("[>] Routing: /%s => %s", domain, target)
    http.Redirect(w, r, target, http.StatusTemporaryRedirect)
}

func main() {
    ports := []int{443, 80, 8899}
    mux := http.NewServeMux()
    mux.HandleFunc("/", proxyHandler)

    for _, port := range ports {
        ln, err := net.Listen("tcp", fmt.Sprintf(":%d", port))
        if err == nil {
            log.Printf("[*] Hive Proxy running on :%d", port)
            log.Fatal(http.Serve(ln, mux))
            return
        }
    }
    log.Fatal("[!] Could not bind to any port")
}
